'use client';

import { useState } from 'react';
import { MapPin, Star, Calendar, Users, Filter } from 'lucide-react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Card, CardContent } from './ui/card';
import { ImageWithFallback } from './figma/ImageWithFallback';

const mapItems = [
  {
    id: 1,
    type: 'Evento',
    name: 'Mostra de Cinema Independente',
    location: 'Centro Cultural São Paulo',
    address: 'Rua Vergueiro, 1000 - Liberdade',
    rating: 4.8,
    reviews: 124,
    date: '20-25 Jan',
    price: 'R$ 25',
    image: 'https://images.unsplash.com/photo-1489599456549-7a7b8a2dd3ab?w=400&h=300&fit=crop',
    tags: ['Cinema', 'Arte', 'Cultura']
  },
  {
    id: 2,
    type: 'Espaço',
    name: 'Teatro Oficina',
    location: 'Bela Vista',
    address: 'Rua Jaceguai, 520 - Bela Vista',
    rating: 4.9,
    reviews: 89,
    date: 'Disponível',
    price: 'R$ 200/hora',
    image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=300&fit=crop',
    tags: ['Teatro', 'Espaço', 'Aluguel']
  },
  {
    id: 3,
    type: 'Evento',
    name: 'Workshop de Fotografia',
    location: 'Pinacoteca do Estado',
    address: 'Pça. da Luz, 2 - Luz',
    rating: 4.7,
    reviews: 56,
    date: '28 Jan',
    price: 'R$ 120',
    image: 'https://images.unsplash.com/photo-1516737488405-7b6d6868fad3?w=400&h=300&fit=crop',
    tags: ['Fotografia', 'Workshop', 'Aprendizado']
  },
  {
    id: 4,
    type: 'Espaço',
    name: 'Galeria Vermelho',
    location: 'Vila Madalena',
    address: 'Rua Minas Gerais, 350 - Higienópolis',
    rating: 4.6,
    reviews: 73,
    date: 'Disponível',
    price: 'R$ 150/hora',
    image: 'https://images.unsplash.com/photo-1518998053901-5348d3961a04?w=400&h=300&fit=crop',
    tags: ['Galeria', 'Arte', 'Exposições']
  }
];

export function MapSection() {
  const [selectedItem, setSelectedItem] = useState<number | null>(null);
  const [filterType, setFilterType] = useState('all');

  const filteredItems = mapItems.filter(item => 
    filterType === 'all' || item.type.toLowerCase() === filterType
  );

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'Evento': return 'bg-blue-100 text-blue-800';
      case 'Espaço': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <section id="mapa" className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl mb-4">Encontre no Mapa</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Explore eventos e espaços culturais próximos a você através do nosso mapa interativo
          </p>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap justify-center gap-4 mb-8">
          <Button
            variant={filterType === 'all' ? 'default' : 'outline'}
            onClick={() => setFilterType('all')}
            className="rounded-full"
          >
            <Filter className="w-4 h-4 mr-2" />
            Todos
          </Button>
          <Button
            variant={filterType === 'evento' ? 'default' : 'outline'}
            onClick={() => setFilterType('evento')}
            className="rounded-full"
          >
            Eventos
          </Button>
          <Button
            variant={filterType === 'espaço' ? 'default' : 'outline'}
            onClick={() => setFilterType('espaço')}
            className="rounded-full"
          >
            Espaços
          </Button>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Map */}
          <div className="lg:col-span-2">
            <div className="bg-gray-100 rounded-2xl h-96 lg:h-[600px] relative overflow-hidden">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1477959858617-67f85cf4f1df?w=800&h=600&fit=crop"
                alt="Mapa de São Paulo"
                className="w-full h-full object-cover opacity-80"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent" />
              
              {/* Map Pins */}
              {filteredItems.map((item, index) => (
                <button
                  key={item.id}
                  onClick={() => setSelectedItem(selectedItem === item.id ? null : item.id)}
                  className={`absolute w-8 h-8 rounded-full border-2 border-white shadow-lg transition-all hover:scale-110 ${
                    item.type === 'Evento' ? 'bg-blue-500' : 'bg-green-500'
                  } ${selectedItem === item.id ? 'scale-125 ring-4 ring-white' : ''}`}
                  style={{
                    left: `${20 + (index * 15)}%`,
                    top: `${30 + (index * 10)}%`
                  }}
                >
                  <MapPin className="w-4 h-4 text-white m-auto" />
                </button>
              ))}

              {/* Selected Item Popup */}
              {selectedItem && (
                <div className="absolute bottom-4 left-4 right-4 bg-white rounded-xl p-4 shadow-xl">
                  {(() => {
                    const item = mapItems.find(i => i.id === selectedItem);
                    if (!item) return null;
                    return (
                      <div className="flex space-x-4">
                        <ImageWithFallback
                          src={item.image}
                          alt={item.name}
                          className="w-16 h-16 rounded-lg object-cover flex-shrink-0"
                        />
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-1">
                            <Badge className={getTypeColor(item.type)}>{item.type}</Badge>
                            <div className="flex items-center">
                              <Star className="w-4 h-4 text-yellow-400 mr-1" />
                              <span className="text-sm">{item.rating}</span>
                            </div>
                          </div>
                          <h3 className="font-medium mb-1">{item.name}</h3>
                          <p className="text-sm text-gray-600">{item.address}</p>
                        </div>
                      </div>
                    );
                  })()}
                </div>
              )}
            </div>
          </div>

          {/* Items List */}
          <div className="space-y-4 max-h-[600px] overflow-y-auto">
            {filteredItems.map((item) => (
              <Card
                key={item.id}
                className={`cursor-pointer transition-all hover:shadow-lg ${
                  selectedItem === item.id ? 'ring-2 ring-primary shadow-lg' : ''
                }`}
                onClick={() => setSelectedItem(selectedItem === item.id ? null : item.id)}
              >
                <CardContent className="p-4">
                  <div className="flex space-x-4">
                    <ImageWithFallback
                      src={item.image}
                      alt={item.name}
                      className="w-20 h-20 rounded-lg object-cover flex-shrink-0"
                    />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center space-x-2 mb-2">
                        <Badge className={getTypeColor(item.type)}>{item.type}</Badge>
                        <div className="flex items-center">
                          <Star className="w-4 h-4 text-yellow-400 mr-1" />
                          <span className="text-sm">{item.rating}</span>
                          <span className="text-sm text-gray-500 ml-1">({item.reviews})</span>
                        </div>
                      </div>
                      <h3 className="font-medium mb-1 truncate">{item.name}</h3>
                      <p className="text-sm text-gray-600 mb-2 truncate">{item.location}</p>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center text-sm text-gray-500">
                          <Calendar className="w-4 h-4 mr-1" />
                          {item.date}
                        </div>
                        <div className="font-medium text-primary">{item.price}</div>
                      </div>
                      <div className="flex flex-wrap gap-1 mt-2">
                        {item.tags.map((tag) => (
                          <Badge key={tag} variant="secondary" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}