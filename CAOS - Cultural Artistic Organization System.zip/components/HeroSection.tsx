'use client';

import { useState } from 'react';
import { ChevronLeft, ChevronRight, Calendar, MapPin, Users } from 'lucide-react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { ImageWithFallback } from './figma/ImageWithFallback';

const highlights = [
  {
    id: 1,
    type: 'Evento',
    title: 'Festival de Jazz no Parque',
    location: 'Parque Ibirapuera, São Paulo',
    date: '15-17 Dez',
    image: 'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=800&h=500&fit=crop',
    description: 'Três dias de jazz com artistas nacionais e internacionais'
  },
  {
    id: 2,
    type: 'Espaço',
    title: 'Galeria Arte Contemporânea',
    location: 'Vila Madalena, São Paulo',
    date: 'Disponível',
    image: 'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=800&h=500&fit=crop',
    description: 'Espaço para exposições e eventos culturais'
  },
  {
    id: 3,
    type: 'Criador',
    title: 'Marina Santos',
    location: 'Artista Visual',
    date: '12 obras',
    image: 'https://images.unsplash.com/photo-1544717297-fa95b6ee9643?w=800&h=500&fit=crop',
    description: 'Especialista em arte urbana e instalações interativas'
  }
];

const quickFilters = [
  { id: 'eventos', label: 'Eventos', count: '250+', active: true },
  { id: 'espacos', label: 'Espaços', count: '120+', active: false },
  { id: 'criadores', label: 'Criadores', count: '300+', active: false }
];

export function HeroSection() {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [activeFilter, setActiveFilter] = useState('eventos');

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % highlights.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + highlights.length) % highlights.length);
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'Evento': return 'bg-blue-500';
      case 'Espaço': return 'bg-green-500';
      case 'Criador': return 'bg-purple-500';
      default: return 'bg-gray-500';
    }
  };

  return (
    <section className="pt-20 pb-8 bg-gradient-to-b from-gray-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Carousel */}
        <div className="relative mb-12">
          <div className="relative h-96 md:h-[500px] overflow-hidden rounded-2xl">
            {highlights.map((item, index) => (
              <div
                key={item.id}
                className={`absolute inset-0 transition-transform duration-500 ease-in-out ${
                  index === currentSlide ? 'translate-x-0' : 'translate-x-full'
                }`}
                style={{
                  transform: `translateX(${(index - currentSlide) * 100}%)`
                }}
              >
                <div className="relative h-full">
                  <ImageWithFallback
                    src={item.image}
                    alt={item.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-black/40" />
                  <div className="absolute bottom-0 left-0 right-0 p-8 text-white">
                    <div className="max-w-2xl">
                      <Badge className={`${getTypeColor(item.type)} text-white mb-4`}>
                        {item.type}
                      </Badge>
                      <h1 className="text-3xl md:text-5xl mb-4">{item.title}</h1>
                      <p className="text-lg md:text-xl mb-4 opacity-90">{item.description}</p>
                      <div className="flex items-center space-x-6 text-sm">
                        <div className="flex items-center">
                          <MapPin className="w-4 h-4 mr-2" />
                          {item.location}
                        </div>
                        <div className="flex items-center">
                          <Calendar className="w-4 h-4 mr-2" />
                          {item.date}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Carousel Controls */}
          <button
            onClick={prevSlide}
            className="absolute left-4 top-1/2 -translate-y-1/2 bg-white/90 hover:bg-white rounded-full p-2 shadow-lg transition-all"
          >
            <ChevronLeft className="w-6 h-6 text-gray-800" />
          </button>
          <button
            onClick={nextSlide}
            className="absolute right-4 top-1/2 -translate-y-1/2 bg-white/90 hover:bg-white rounded-full p-2 shadow-lg transition-all"
          >
            <ChevronRight className="w-6 h-6 text-gray-800" />
          </button>

          {/* Carousel Indicators */}
          <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex space-x-2">
            {highlights.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentSlide(index)}
                className={`w-2 h-2 rounded-full transition-all ${
                  index === currentSlide ? 'bg-white' : 'bg-white/50'
                }`}
              />
            ))}
          </div>
        </div>

        {/* Quick Filters */}
        <div className="flex flex-col md:flex-row items-center justify-center space-y-4 md:space-y-0 md:space-x-8">
          {quickFilters.map((filter) => (
            <button
              key={filter.id}
              onClick={() => setActiveFilter(filter.id)}
              className={`flex items-center px-8 py-4 rounded-full border-2 transition-all hover:scale-105 ${
                activeFilter === filter.id
                  ? 'border-primary bg-primary text-white'
                  : 'border-gray-300 bg-white hover:border-primary'
              }`}
            >
              <Users className="w-5 h-5 mr-3" />
              <div className="text-left">
                <div className="font-medium">{filter.label}</div>
                <div className={`text-sm ${activeFilter === filter.id ? 'text-white/80' : 'text-gray-500'}`}>
                  {filter.count} disponíveis
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>
    </section>
  );
}