'use client';

import { useState } from 'react';
import { Calendar, Users, MapPin, Star, Clock } from 'lucide-react';
import { Card, CardContent } from './ui/card';
import { Avatar, AvatarImage, AvatarFallback } from './ui/avatar';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { ImageWithFallback } from './figma/ImageWithFallback';

const spaceEvents = [
  {
    id: 1,
    spaceName: 'Centro Cultural São Paulo',
    spaceImage: 'https://images.unsplash.com/photo-1518998053901-5348d3961a04?w=400&h=200&fit=crop',
    events: [
      {
        id: 101,
        title: 'Mostra de Cinema Independente',
        date: '20-25 Jan',
        time: '19:00',
        image: 'https://images.unsplash.com/photo-1489599456549-7a7b8a2dd3ab?w=300&h=200&fit=crop',
        category: 'Cinema'
      },
      {
        id: 102,
        title: 'Exposição Arte Urbana',
        date: '15 Fev - 15 Mar',
        time: '10:00-18:00',
        image: 'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=300&h=200&fit=crop',
        category: 'Arte Visual'
      }
    ]
  },
  {
    id: 2,
    spaceName: 'Galeria Vermelho',
    spaceImage: 'https://images.unsplash.com/photo-1513475382585-d06e58bcb0e0?w=400&h=200&fit=crop',
    events: [
      {
        id: 103,
        title: 'Vernissage Coletiva',
        date: '28 Jan',
        time: '20:00',
        image: 'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=300&h=200&fit=crop',
        category: 'Arte Visual'
      }
    ]
  }
];

const creatorProfiles = [
  {
    id: 1,
    name: 'Marina Santos',
    avatar: 'https://images.unsplash.com/photo-1544717297-fa95b6ee9643?w=100&h=100&fit=crop',
    category: 'Artista Visual',
    rating: 4.9,
    participations: 12,
    verified: true,
    bio: 'Especialista em arte urbana e instalações interativas com mais de 10 anos de experiência.',
    recentWorks: [
      {
        title: 'Instalação "Memórias Urbanas"',
        space: 'Pinacoteca do Estado',
        date: 'Dez 2024'
      },
      {
        title: 'Workshop Grafite Consciente',
        space: 'Casa das Rosas',
        date: 'Nov 2024'
      }
    ],
    upcomingEvents: [
      {
        title: 'Palestra sobre Arte Urbana',
        date: '5 Fev',
        space: 'Centro Cultural'
      }
    ]
  },
  {
    id: 2,
    name: 'Carlos Melodia',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop',
    category: 'Músico',
    rating: 4.8,
    participations: 25,
    verified: true,
    bio: 'Compositor e multi-instrumentista especializado em música acústica e world music.',
    recentWorks: [
      {
        title: 'Show "Melodias do Mundo"',
        space: 'Sala São Paulo',
        date: 'Jan 2025'
      },
      {
        title: 'Oficina de Composição',
        space: 'Conservatório',
        date: 'Dez 2024'
      }
    ],
    upcomingEvents: [
      {
        title: 'Apresentação Solo',
        date: '15 Fev',
        space: 'Teatro Municipal'
      }
    ]
  },
  {
    id: 3,
    name: 'Ana Dramática',
    avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop',
    category: 'Atriz e Diretora',
    rating: 4.9,
    participations: 18,
    verified: true,
    bio: 'Diretora teatral com foco em dramaturgia contemporânea e teatro experimental.',
    recentWorks: [
      {
        title: 'Direção "Vozes da Cidade"',
        space: 'Teatro Oficina',
        date: 'Dez 2024'
      },
      {
        title: 'Workshop de Interpretação',
        space: 'Espaço Cultura',
        date: 'Nov 2024'
      }
    ],
    upcomingEvents: [
      {
        title: 'Estreia "Novos Tempos"',
        date: '20 Fev',
        space: 'Teatro Sérgio Cardoso'
      }
    ]
  }
];

export function IntersectionTabs() {
  const [selectedSpace, setSelectedSpace] = useState<number>(1);
  const [selectedCreator, setSelectedCreator] = useState<number>(1);

  return (
    <section className="py-16 bg-gradient-to-b from-white to-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl mb-4">Conexões Culturais</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Explore as relações entre espaços, eventos e criadores da nossa rede cultural
          </p>
        </div>

        <Tabs defaultValue="spaces" className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-8">
            <TabsTrigger value="spaces" className="flex items-center space-x-2">
              <MapPin className="w-4 h-4" />
              <span>Agenda por Espaço</span>
            </TabsTrigger>
            <TabsTrigger value="creators" className="flex items-center space-x-2">
              <Users className="w-4 h-4" />
              <span>Perfis de Criadores</span>
            </TabsTrigger>
          </TabsList>

          {/* Spaces Tab */}
          <TabsContent value="spaces">
            <div className="grid lg:grid-cols-3 gap-8">
              {/* Spaces List */}
              <div className="space-y-4">
                <h3 className="text-xl font-medium mb-4">Espaços Culturais</h3>
                {spaceEvents.map((space) => (
                  <Card
                    key={space.id}
                    className={`cursor-pointer transition-all hover:shadow-lg ${
                      selectedSpace === space.id ? 'ring-2 ring-primary shadow-lg' : ''
                    }`}
                    onClick={() => setSelectedSpace(space.id)}
                  >
                    <CardContent className="p-4">
                      <div className="flex space-x-4">
                        <ImageWithFallback
                          src={space.spaceImage}
                          alt={space.spaceName}
                          className="w-16 h-16 rounded-lg object-cover flex-shrink-0"
                        />
                        <div className="flex-1">
                          <h4 className="font-medium mb-1">{space.spaceName}</h4>
                          <p className="text-sm text-gray-600 mb-2">
                            {space.events.length} eventos agendados
                          </p>
                          <Badge variant="outline" className="text-xs">
                            Ver Agenda
                          </Badge>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* Selected Space Details */}
              <div className="lg:col-span-2">
                {spaceEvents
                  .filter(space => space.id === selectedSpace)
                  .map(space => (
                    <div key={space.id}>
                      <div className="flex items-center space-x-4 mb-6">
                        <ImageWithFallback
                          src={space.spaceImage}
                          alt={space.spaceName}
                          className="w-20 h-20 rounded-lg object-cover"
                        />
                        <div>
                          <h3 className="text-2xl font-medium mb-1">{space.spaceName}</h3>
                          <p className="text-gray-600">Agenda de eventos</p>
                        </div>
                      </div>

                      <div className="grid gap-6">
                        {space.events.map((event) => (
                          <Card key={event.id} className="hover:shadow-lg transition-shadow">
                            <CardContent className="p-6">
                              <div className="flex space-x-6">
                                <ImageWithFallback
                                  src={event.image}
                                  alt={event.title}
                                  className="w-32 h-24 rounded-lg object-cover flex-shrink-0"
                                />
                                <div className="flex-1">
                                  <div className="flex items-center space-x-2 mb-2">
                                    <Badge className="bg-primary text-white">
                                      {event.category}
                                    </Badge>
                                  </div>
                                  <h4 className="text-xl font-medium mb-2">{event.title}</h4>
                                  <div className="flex items-center space-x-4 text-gray-600 mb-4">
                                    <div className="flex items-center">
                                      <Calendar className="w-4 h-4 mr-2" />
                                      {event.date}
                                    </div>
                                    <div className="flex items-center">
                                      <Clock className="w-4 h-4 mr-2" />
                                      {event.time}
                                    </div>
                                  </div>
                                  <Button>Ver Detalhes</Button>
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          </TabsContent>

          {/* Creators Tab */}
          <TabsContent value="creators">
            <div className="grid lg:grid-cols-3 gap-8">
              {/* Creators List */}
              <div className="space-y-4">
                <h3 className="text-xl font-medium mb-4">Criadores</h3>
                {creatorProfiles.map((creator) => (
                  <Card
                    key={creator.id}
                    className={`cursor-pointer transition-all hover:shadow-lg ${
                      selectedCreator === creator.id ? 'ring-2 ring-primary shadow-lg' : ''
                    }`}
                    onClick={() => setSelectedCreator(creator.id)}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-center space-x-4">
                        <Avatar className="w-16 h-16">
                          <AvatarImage src={creator.avatar} alt={creator.name} />
                          <AvatarFallback>{creator.name[0]}</AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-1">
                            <h4 className="font-medium">{creator.name}</h4>
                            {creator.verified && (
                              <Badge variant="secondary" className="text-xs">Verificado</Badge>
                            )}
                          </div>
                          <p className="text-sm text-gray-600 mb-2">{creator.category}</p>
                          <div className="flex items-center space-x-4 text-xs text-gray-500">
                            <div className="flex items-center">
                              <Star className="w-3 h-3 mr-1 text-yellow-400" />
                              {creator.rating}
                            </div>
                            <span>{creator.participations} participações</span>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* Selected Creator Profile */}
              <div className="lg:col-span-2">
                {creatorProfiles
                  .filter(creator => creator.id === selectedCreator)
                  .map(creator => (
                    <div key={creator.id}>
                      {/* Profile Header */}
                      <div className="flex items-start space-x-6 mb-8">
                        <Avatar className="w-24 h-24">
                          <AvatarImage src={creator.avatar} alt={creator.name} />
                          <AvatarFallback>{creator.name[0]}</AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-2">
                            <h3 className="text-2xl font-medium">{creator.name}</h3>
                            {creator.verified && (
                              <Badge className="bg-green-100 text-green-800">Verificado</Badge>
                            )}
                          </div>
                          <p className="text-lg text-gray-600 mb-3">{creator.category}</p>
                          <div className="flex items-center space-x-6 text-sm text-gray-500 mb-4">
                            <div className="flex items-center">
                              <Star className="w-4 h-4 mr-2 text-yellow-400" />
                              {creator.rating} de avaliação
                            </div>
                            <span>{creator.participations} participações</span>
                          </div>
                          <p className="text-gray-700 mb-4">{creator.bio}</p>
                          <div className="flex space-x-3">
                            <Button>Seguir</Button>
                            <Button variant="outline">Contratar</Button>
                          </div>
                        </div>
                      </div>

                      <div className="grid md:grid-cols-2 gap-6">
                        {/* Recent Works */}
                        <Card>
                          <CardContent className="p-6">
                            <h4 className="font-medium mb-4">Trabalhos Recentes</h4>
                            <div className="space-y-4">
                              {creator.recentWorks.map((work, index) => (
                                <div key={index} className="border-l-2 border-primary pl-4">
                                  <h5 className="font-medium text-sm">{work.title}</h5>
                                  <p className="text-sm text-gray-600">{work.space}</p>
                                  <p className="text-xs text-gray-500">{work.date}</p>
                                </div>
                              ))}
                            </div>
                          </CardContent>
                        </Card>

                        {/* Upcoming Events */}
                        <Card>
                          <CardContent className="p-6">
                            <h4 className="font-medium mb-4">Próximos Eventos</h4>
                            <div className="space-y-4">
                              {creator.upcomingEvents.map((event, index) => (
                                <div key={index} className="border-l-2 border-green-500 pl-4">
                                  <h5 className="font-medium text-sm">{event.title}</h5>
                                  <p className="text-sm text-gray-600">{event.space}</p>
                                  <div className="flex items-center text-xs text-gray-500">
                                    <Calendar className="w-3 h-3 mr-1" />
                                    {event.date}
                                  </div>
                                </div>
                              ))}
                            </div>
                          </CardContent>
                        </Card>
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </section>
  );
}