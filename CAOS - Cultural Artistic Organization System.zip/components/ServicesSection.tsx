'use client';

import { useState } from 'react';
import { Filter, Star, Clock, MapPin, ChevronDown } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { Badge } from './ui/badge';
import { Avatar, AvatarImage, AvatarFallback } from './ui/avatar';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { ImageWithFallback } from './figma/ImageWithFallback';

const services = [
  {
    id: 1,
    title: 'Show Acústico Personalizado',
    artist: {
      name: 'João Melodia',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop',
      verified: true
    },
    category: 'Música',
    type: 'Show',
    duration: '2-3 horas',
    location: 'Disponível em SP',
    rating: 4.9,
    reviews: 67,
    priceRange: 'R$ 800 - R$ 1.500',
    image: 'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=400&h=300&fit=crop',
    description: 'Apresentações íntimas com repertório personalizado para seu evento',
    tags: ['Música', 'Acústico', 'Personalizado']
  },
  {
    id: 2,
    title: 'Oficina de Arte Urbana',
    artist: {
      name: 'Street Art Coletivo',
      avatar: 'https://images.unsplash.com/photo-1544717297-fa95b6ee9643?w=100&h=100&fit=crop',
      verified: true
    },
    category: 'Arte Visual',
    type: 'Workshop',
    duration: '4 horas',
    location: 'Vila Madalena',
    rating: 4.8,
    reviews: 43,
    priceRange: 'R$ 150 - R$ 200',
    image: 'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=400&h=300&fit=crop',
    description: 'Aprenda técnicas de grafite e stencil com artistas urbanos renomados',
    tags: ['Arte Urbana', 'Grafite', 'Workshop']
  },
  {
    id: 3,
    title: 'Consultoria em Produção Cultural',
    artist: {
      name: 'Marina Cultura',
      avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b550?w=100&h=100&fit=crop',
      verified: true
    },
    category: 'Consultoria',
    type: 'Serviço',
    duration: 'Flexível',
    location: 'Online/Presencial',
    rating: 5.0,
    reviews: 28,
    priceRange: 'R$ 200 - R$ 500',
    image: 'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?w=400&h=300&fit=crop',
    description: 'Planejamento e execução de projetos culturais e eventos artísticos',
    tags: ['Consultoria', 'Produção', 'Planejamento']
  },
  {
    id: 4,
    title: 'Performance de Dança Contemporânea',
    artist: {
      name: 'Cia. Movimento',
      avatar: 'https://images.unsplash.com/photo-1516737488405-7b6d6868fad3?w=100&h=100&fit=crop',
      verified: true
    },
    category: 'Dança',
    type: 'Performance',
    duration: '30-60 min',
    location: 'Diversos espaços',
    rating: 4.7,
    reviews: 52,
    priceRange: 'R$ 1.000 - R$ 2.000',
    image: 'https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?w=400&h=300&fit=crop',
    description: 'Espetáculos de dança contemporânea para eventos e espaços culturais',
    tags: ['Dança', 'Performance', 'Contemporâneo']
  },
  {
    id: 5,
    title: 'Workshop de Fotografia Artística',
    artist: {
      name: 'Pedro Lens',
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop',
      verified: true
    },
    category: 'Fotografia',
    type: 'Workshop',
    duration: '6 horas',
    location: 'Centro de SP',
    rating: 4.8,
    reviews: 39,
    priceRange: 'R$ 250 - R$ 350',
    image: 'https://images.unsplash.com/photo-1516737488405-7b6d6868fad3?w=400&h=300&fit=crop',
    description: 'Técnicas avançadas de composição e pós-produção para fotografia artística',
    tags: ['Fotografia', 'Arte', 'Técnica']
  },
  {
    id: 6,
    title: 'Aulas Particulares de Teatro',
    artist: {
      name: 'Ana Dramática',
      avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop',
      verified: true
    },
    category: 'Teatro',
    type: 'Aula',
    duration: '1-2 horas',
    location: 'Flexível',
    rating: 4.9,
    reviews: 76,
    priceRange: 'R$ 120 - R$ 180',
    image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=300&fit=crop',
    description: 'Desenvolvimento de técnicas teatrais individuais com método personalizado',
    tags: ['Teatro', 'Aulas', 'Individual']
  }
];

const categories = ['Todos', 'Música', 'Arte Visual', 'Dança', 'Teatro', 'Fotografia', 'Consultoria'];
const serviceTypes = ['Todos', 'Show', 'Workshop', 'Performance', 'Consultoria', 'Aula'];
const priceRanges = ['Todos', 'Até R$ 200', 'R$ 200 - R$ 500', 'R$ 500 - R$ 1.000', 'Acima R$ 1.000'];

export function ServicesSection() {
  const [selectedCategory, setSelectedCategory] = useState('Todos');
  const [selectedType, setSelectedType] = useState('Todos');
  const [selectedPriceRange, setSelectedPriceRange] = useState('Todos');
  const [sortBy, setSortBy] = useState('rating');

  const filteredServices = services.filter(service => {
    if (selectedCategory !== 'Todos' && service.category !== selectedCategory) return false;
    if (selectedType !== 'Todos' && service.type !== selectedType) return false;
    // Simplified price filtering for demo
    return true;
  }).sort((a, b) => {
    if (sortBy === 'rating') return b.rating - a.rating;
    if (sortBy === 'reviews') return b.reviews - a.reviews;
    return 0;
  });

  return (
    <section id="servicos" className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl mb-4">Serviços Artísticos</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Contrate artistas e criadores para shows, workshops, consultorias e performances
          </p>
        </div>

        {/* Filters */}
        <div className="bg-gray-50 rounded-2xl p-6 mb-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
            <div>
              <label className="block text-sm font-medium mb-2">Categoria</label>
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {categories.map(category => (
                    <SelectItem key={category} value={category}>
                      {category}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Tipo de Serviço</label>
              <Select value={selectedType} onValueChange={setSelectedType}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {serviceTypes.map(type => (
                    <SelectItem key={type} value={type}>
                      {type}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Faixa de Preço</label>
              <Select value={selectedPriceRange} onValueChange={setSelectedPriceRange}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {priceRanges.map(range => (
                    <SelectItem key={range} value={range}>
                      {range}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Ordenar por</label>
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="rating">Melhor Avaliação</SelectItem>
                  <SelectItem value="reviews">Mais Avaliações</SelectItem>
                  <SelectItem value="price">Menor Preço</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-end">
              <Button className="w-full">
                <Filter className="w-4 h-4 mr-2" />
                Filtrar
              </Button>
            </div>
          </div>
        </div>

        {/* Results */}
        <div className="mb-6 flex items-center justify-between">
          <p className="text-gray-600">
            {filteredServices.length} serviços encontrados
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredServices.map((service) => (
            <Card key={service.id} className="hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
              <div className="relative">
                <ImageWithFallback
                  src={service.image}
                  alt={service.title}
                  className="w-full h-48 object-cover rounded-t-lg"
                />
                <Badge className="absolute top-4 left-4 bg-primary text-white">
                  {service.type}
                </Badge>
                <div className="absolute top-4 right-4 bg-white rounded-full px-2 py-1 flex items-center space-x-1">
                  <Star className="w-3 h-3 text-yellow-400" />
                  <span className="text-xs font-medium">{service.rating}</span>
                </div>
              </div>
              
              <CardContent className="p-6">
                {/* Artist Info */}
                <div className="flex items-center space-x-3 mb-4">
                  <Avatar className="w-10 h-10">
                    <AvatarImage src={service.artist.avatar} alt={service.artist.name} />
                    <AvatarFallback>{service.artist.name[0]}</AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="flex items-center space-x-2">
                      <span className="font-medium text-sm">{service.artist.name}</span>
                      {service.artist.verified && (
                        <Badge variant="secondary" className="text-xs">Verificado</Badge>
                      )}
                    </div>
                    <div className="flex items-center text-xs text-gray-500">
                      <Star className="w-3 h-3 mr-1 text-yellow-400" />
                      {service.rating} ({service.reviews} avaliações)
                    </div>
                  </div>
                </div>

                {/* Service Info */}
                <div className="mb-4">
                  <h3 className="font-semibold mb-2">{service.title}</h3>
                  <p className="text-gray-600 text-sm mb-3">{service.description}</p>
                  
                  <div className="space-y-2 text-sm text-gray-500">
                    <div className="flex items-center">
                      <Clock className="w-4 h-4 mr-2" />
                      {service.duration}
                    </div>
                    <div className="flex items-center">
                      <MapPin className="w-4 h-4 mr-2" />
                      {service.location}
                    </div>
                  </div>
                </div>

                {/* Tags */}
                <div className="flex flex-wrap gap-1 mb-4">
                  {service.tags.map((tag) => (
                    <Badge key={tag} variant="outline" className="text-xs">
                      {tag}
                    </Badge>
                  ))}
                </div>

                {/* Price and Action */}
                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-semibold text-primary">{service.priceRange}</div>
                    <div className="text-xs text-gray-500">{service.category}</div>
                  </div>
                  <Button size="sm">
                    Contratar
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Load More */}
        <div className="text-center mt-12">
          <Button variant="outline" size="lg">
            Ver Mais Serviços
          </Button>
        </div>
      </div>
    </section>
  );
}