'use client';

import { useState } from 'react';
import { ChevronLeft, ChevronRight, Star, Clock, Users, Heart, MessageCircle } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { Avatar, AvatarImage, AvatarFallback } from './ui/avatar';
import { Badge } from './ui/badge';
import { ImageWithFallback } from './figma/ImageWithFallback';

const experiences = [
  {
    id: 1,
    title: 'Tour Grafite Vila Madalena',
    description: 'Descubra a arte urbana com guias locais especializados',
    duration: '3 horas',
    participants: 12,
    rating: 4.9,
    price: 'R$ 85',
    image: 'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=400&h=300&fit=crop',
    host: {
      name: 'Carlos Silva',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop'
    },
    category: 'Tour'
  },
  {
    id: 2,
    title: 'Workshop de Cerâmica',
    description: 'Aprenda técnicas tradicionais de modelagem em argila',
    duration: '4 horas',
    participants: 8,
    rating: 4.8,
    price: 'R$ 150',
    image: 'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=400&h=300&fit=crop',
    host: {
      name: 'Ana Costa',
      avatar: 'https://images.unsplash.com/photo-1544717297-fa95b6ee9643?w=100&h=100&fit=crop'
    },
    category: 'Workshop'
  },
  {
    id: 3,
    title: 'Residência Artística',
    description: 'Programa intensivo de criação artística de 30 dias',
    duration: '30 dias',
    participants: 5,
    rating: 4.7,
    price: 'R$ 2.500',
    image: 'https://images.unsplash.com/photo-1513475382585-d06e58bcb0e0?w=400&h=300&fit=crop',
    host: {
      name: 'Instituto Criar',
      avatar: 'https://images.unsplash.com/photo-1516737488405-7b6d6868fad3?w=100&h=100&fit=crop'
    },
    category: 'Residência'
  }
];

const testimonials = [
  {
    id: 1,
    name: 'Mariana Santos',
    avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b550?w=100&h=100&fit=crop',
    rating: 5,
    text: 'O tour de grafite foi incrível! Descobri uma São Paulo que não conhecia. O Carlos é um excelente guia e conhece cada história por trás das obras.',
    experience: 'Tour Grafite Vila Madalena',
    date: '2 dias atrás'
  },
  {
    id: 2,
    name: 'Pedro Oliveira',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop',
    rating: 5,
    text: 'A residência artística mudou minha perspectiva como artista. Ambiente inspirador e networking valioso com outros criadores.',
    experience: 'Residência Artística',
    date: '1 semana atrás'
  },
  {
    id: 3,
    name: 'Lucia Fernandes',
    avatar: 'https://images.unsplash.com/photo-1544717297-fa95b6ee9643?w=100&h=100&fit=crop',
    rating: 4,
    text: 'Workshop de cerâmica superou expectativas. Saí com peças lindas e muita vontade de continuar praticando!',
    experience: 'Workshop de Cerâmica',
    date: '3 dias atrás'
  }
];

const communityHighlights = [
  {
    id: 1,
    type: 'Conquista',
    title: 'Comunidade CAOS alcança 10.000 membros!',
    description: 'Celebramos este marco incrível da nossa comunidade criativa',
    likes: 245,
    comments: 32,
    image: 'https://images.unsplash.com/photo-1511632765486-a01980e01a18?w=400&h=200&fit=crop'
  },
  {
    id: 2,
    type: 'Novidade',
    title: 'Nova funcionalidade: Colaborações',
    description: 'Agora você pode encontrar parceiros para projetos colaborativos',
    likes: 189,
    comments: 28,
    image: 'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?w=400&h=200&fit=crop'
  }
];

export function ExperiencesSection() {
  const [currentExperience, setCurrentExperience] = useState(0);

  const nextExperience = () => {
    setCurrentExperience((prev) => (prev + 1) % experiences.length);
  };

  const prevExperience = () => {
    setCurrentExperience((prev) => (prev - 1 + experiences.length) % experiences.length);
  };

  return (
    <section id="experiencias" className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Experiências */}
        <div className="mb-16">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl mb-4">Experiências Únicas</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Participe de workshops, tours e residências artísticas com criadores locais
            </p>
          </div>

          <div className="relative">
            <div className="overflow-hidden rounded-2xl">
              <div
                className="flex transition-transform duration-300 ease-in-out"
                style={{ transform: `translateX(-${currentExperience * (100 / 3)}%)` }}
              >
                {experiences.map((experience) => (
                  <div key={experience.id} className="w-full md:w-1/2 lg:w-1/3 flex-shrink-0 px-4">
                    <Card className="h-full hover:shadow-xl transition-shadow">
                      <div className="relative">
                        <ImageWithFallback
                          src={experience.image}
                          alt={experience.title}
                          className="w-full h-48 object-cover rounded-t-lg"
                        />
                        <Badge className="absolute top-4 left-4 bg-white text-gray-800">
                          {experience.category}
                        </Badge>
                        <Button
                          size="sm"
                          variant="ghost"
                          className="absolute top-4 right-4 bg-white/90 hover:bg-white"
                        >
                          <Heart className="w-4 h-4" />
                        </Button>
                      </div>
                      <CardContent className="p-6">
                        <div className="flex items-center space-x-2 mb-3">
                          <Avatar className="w-8 h-8">
                            <AvatarImage src={experience.host.avatar} alt={experience.host.name} />
                            <AvatarFallback>{experience.host.name[0]}</AvatarFallback>
                          </Avatar>
                          <span className="text-sm text-gray-600">por {experience.host.name}</span>
                        </div>
                        <h3 className="font-semibold mb-2">{experience.title}</h3>
                        <p className="text-gray-600 text-sm mb-4">{experience.description}</p>
                        
                        <div className="flex items-center space-x-4 mb-4 text-sm text-gray-500">
                          <div className="flex items-center">
                            <Clock className="w-4 h-4 mr-1" />
                            {experience.duration}
                          </div>
                          <div className="flex items-center">
                            <Users className="w-4 h-4 mr-1" />
                            até {experience.participants}
                          </div>
                          <div className="flex items-center">
                            <Star className="w-4 h-4 mr-1 text-yellow-400" />
                            {experience.rating}
                          </div>
                        </div>
                        
                        <div className="flex items-center justify-between">
                          <div className="text-lg font-semibold text-primary">
                            {experience.price}
                          </div>
                          <Button size="sm">Reservar</Button>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                ))}
              </div>
            </div>

            <Button
              variant="outline"
              size="sm"
              className="absolute left-4 top-1/2 -translate-y-1/2 rounded-full bg-white shadow-lg"
              onClick={prevExperience}
            >
              <ChevronLeft className="w-4 h-4" />
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="absolute right-4 top-1/2 -translate-y-1/2 rounded-full bg-white shadow-lg"
              onClick={nextExperience}
            >
              <ChevronRight className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* Comunidade */}
        <div>
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl mb-4">Nossa Comunidade</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Histórias, conquistas e novidades da nossa rede cultural
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-8 mb-12">
            {/* Testimonials */}
            <div>
              <h3 className="text-2xl font-medium mb-6">Depoimentos</h3>
              <div className="space-y-6">
                {testimonials.map((testimonial) => (
                  <Card key={testimonial.id}>
                    <CardContent className="p-6">
                      <div className="flex items-start space-x-4">
                        <Avatar>
                          <AvatarImage src={testimonial.avatar} alt={testimonial.name} />
                          <AvatarFallback>{testimonial.name[0]}</AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-2">
                            <span className="font-medium">{testimonial.name}</span>
                            <div className="flex">
                              {[...Array(testimonial.rating)].map((_, i) => (
                                <Star key={i} className="w-4 h-4 text-yellow-400 fill-current" />
                              ))}
                            </div>
                            <span className="text-sm text-gray-500">{testimonial.date}</span>
                          </div>
                          <p className="text-gray-700 mb-2">{testimonial.text}</p>
                          <p className="text-sm text-gray-500">
                            Experiência: {testimonial.experience}
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>

            {/* Community Highlights */}
            <div>
              <h3 className="text-2xl font-medium mb-6">Novidades da Comunidade</h3>
              <div className="space-y-6">
                {communityHighlights.map((highlight) => (
                  <Card key={highlight.id} className="hover:shadow-lg transition-shadow">
                    <div className="relative">
                      <ImageWithFallback
                        src={highlight.image}
                        alt={highlight.title}
                        className="w-full h-32 object-cover rounded-t-lg"
                      />
                      <Badge className="absolute top-4 left-4 bg-primary text-white">
                        {highlight.type}
                      </Badge>
                    </div>
                    <CardContent className="p-6">
                      <h4 className="font-semibold mb-2">{highlight.title}</h4>
                      <p className="text-gray-600 text-sm mb-4">{highlight.description}</p>
                      <div className="flex items-center space-x-4 text-sm text-gray-500">
                        <div className="flex items-center">
                          <Heart className="w-4 h-4 mr-1" />
                          {highlight.likes}
                        </div>
                        <div className="flex items-center">
                          <MessageCircle className="w-4 h-4 mr-1" />
                          {highlight.comments}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}