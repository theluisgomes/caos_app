import { Facebook, Instagram, Twitter, Youtube, Mail, Phone, MapPin } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Separator } from './ui/separator';

export function Footer() {
  return (
    <footer className="bg-gray-900 text-gray-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Main Footer Content */}
        <div className="py-12">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {/* Company Info */}
            <div>
              <div className="text-2xl font-bold text-white mb-4">CAOS</div>
              <p className="text-sm mb-6 leading-relaxed">
                Cultural Artistic Organization System - Conectando criadores, espaços e experiências culturais em uma única plataforma.
              </p>
              
              <div className="space-y-2 text-sm">
                <div className="flex items-center">
                  <MapPin className="w-4 h-4 mr-2" />
                  São Paulo, SP - Brasil
                </div>
                <div className="flex items-center">
                  <Mail className="w-4 h-4 mr-2" />
                  contato@caos.art.br
                </div>
                <div className="flex items-center">
                  <Phone className="w-4 h-4 mr-2" />
                  (11) 9999-8888
                </div>
              </div>
            </div>

            {/* Explore */}
            <div>
              <h3 className="text-white font-medium mb-4">Explorar</h3>
              <div className="space-y-3 text-sm">
                <a href="#eventos" className="block hover:text-white transition-colors">Eventos</a>
                <a href="#espacos" className="block hover:text-white transition-colors">Espaços</a>
                <a href="#criadores" className="block hover:text-white transition-colors">Criadores</a>
                <a href="#experiencias" className="block hover:text-white transition-colors">Experiências</a>
                <a href="#servicos" className="block hover:text-white transition-colors">Serviços</a>
                <a href="#mapa" className="block hover:text-white transition-colors">Mapa</a>
              </div>
            </div>

            {/* Community */}
            <div>
              <h3 className="text-white font-medium mb-4">Comunidade</h3>
              <div className="space-y-3 text-sm">
                <a href="#sobre" className="block hover:text-white transition-colors">Sobre Nós</a>
                <a href="#blog" className="block hover:text-white transition-colors">Blog</a>
                <a href="#carreiras" className="block hover:text-white transition-colors">Carreiras</a>
                <a href="#imprensa" className="block hover:text-white transition-colors">Imprensa</a>
                <a href="#parceiros" className="block hover:text-white transition-colors">Parceiros</a>
                <a href="#programa-artistas" className="block hover:text-white transition-colors">Programa para Artistas</a>
              </div>
            </div>

            {/* Newsletter */}
            <div>
              <h3 className="text-white font-medium mb-4">Newsletter</h3>
              <p className="text-sm mb-4">
                Receba as últimas novidades sobre eventos culturais e oportunidades artísticas.
              </p>
              <div className="space-y-3">
                <Input 
                  type="email" 
                  placeholder="Seu melhor e-mail"
                  className="bg-gray-800 border-gray-700 text-white placeholder-gray-400"
                />
                <Button className="w-full bg-primary hover:bg-primary/90">
                  Inscrever-se
                </Button>
              </div>
            </div>
          </div>
        </div>

        <Separator className="bg-gray-700" />

        {/* Bottom Footer */}
        <div className="py-6">
          <div className="flex flex-col md:flex-row items-center justify-between space-y-4 md:space-y-0">
            {/* Copyright */}
            <div className="text-sm">
              © 2025 CAOS - Cultural Artistic Organization System. Todos os direitos reservados.
            </div>

            {/* Social Links */}
            <div className="flex items-center space-x-4">
              <a
                href="#"
                className="w-8 h-8 bg-gray-800 rounded-full flex items-center justify-center hover:bg-gray-700 transition-colors"
              >
                <Facebook className="w-4 h-4" />
              </a>
              <a
                href="#"
                className="w-8 h-8 bg-gray-800 rounded-full flex items-center justify-center hover:bg-gray-700 transition-colors"
              >
                <Instagram className="w-4 h-4" />
              </a>
              <a
                href="#"
                className="w-8 h-8 bg-gray-800 rounded-full flex items-center justify-center hover:bg-gray-700 transition-colors"
              >
                <Twitter className="w-4 h-4" />
              </a>
              <a
                href="#"
                className="w-8 h-8 bg-gray-800 rounded-full flex items-center justify-center hover:bg-gray-700 transition-colors"
              >
                <Youtube className="w-4 h-4" />
              </a>
            </div>

            {/* Legal Links */}
            <div className="flex items-center space-x-6 text-sm">
              <a href="#privacidade" className="hover:text-white transition-colors">
                Política de Privacidade
              </a>
              <a href="#termos" className="hover:text-white transition-colors">
                Termos de Uso
              </a>
              <a href="#suporte" className="hover:text-white transition-colors">
                Suporte
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}