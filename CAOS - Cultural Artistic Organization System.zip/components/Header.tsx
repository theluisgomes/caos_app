'use client';

import { useState } from 'react';
import { Search, MapPin, Calendar, Tag, Menu, X } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Sheet, SheetContent, SheetTrigger } from './ui/sheet';

export function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="fixed top-0 w-full bg-white/95 backdrop-blur-sm z-50 border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center">
            <div className="text-2xl font-bold text-primary">CAOS</div>
            <div className="hidden sm:block text-sm text-gray-500 ml-2">
              Cultural Artistic Organization System
            </div>
          </div>

          {/* Search Bar - Desktop */}
          <div className="hidden lg:flex items-center bg-white border border-gray-300 rounded-full p-2 shadow-sm hover:shadow-md transition-shadow max-w-lg flex-1 mx-8">
            <div className="flex items-center px-4 border-r border-gray-300">
              <Search className="w-4 h-4 text-gray-400 mr-2" />
              <input
                type="text"
                placeholder="O que você procura?"
                className="border-0 outline-none bg-transparent text-sm w-full"
              />
            </div>
            <div className="flex items-center px-4 border-r border-gray-300">
              <MapPin className="w-4 h-4 text-gray-400 mr-2" />
              <input
                type="text"
                placeholder="Localização"
                className="border-0 outline-none bg-transparent text-sm w-20"
              />
            </div>
            <div className="flex items-center px-4 border-r border-gray-300">
              <Calendar className="w-4 h-4 text-gray-400 mr-2" />
              <input
                type="text"
                placeholder="Data"
                className="border-0 outline-none bg-transparent text-sm w-16"
              />
            </div>
            <div className="flex items-center px-4">
              <Tag className="w-4 h-4 text-gray-400 mr-2" />
              <input
                type="text"
                placeholder="Tipo"
                className="border-0 outline-none bg-transparent text-sm w-16"
              />
            </div>
            <Button size="sm" className="rounded-full bg-primary hover:bg-primary/90">
              <Search className="w-4 h-4" />
            </Button>
          </div>

          {/* Navigation - Desktop */}
          <nav className="hidden lg:flex items-center space-x-8">
            <a href="#explorar" className="text-gray-700 hover:text-primary transition-colors">Explorar</a>
            <a href="#mapa" className="text-gray-700 hover:text-primary transition-colors">Mapa</a>
            <a href="#experiencias" className="text-gray-700 hover:text-primary transition-colors">Experiências</a>
            <a href="#servicos" className="text-gray-700 hover:text-primary transition-colors">Serviços</a>
            <a href="#comunidade" className="text-gray-700 hover:text-primary transition-colors">Comunidade</a>
          </nav>

          {/* Login Button - Desktop */}
          <div className="hidden lg:block">
            <Button variant="outline" className="rounded-full">
              Entrar/Cadastrar-se
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="sm" className="lg:hidden">
                <Menu className="w-6 h-6" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-80">
              <div className="flex flex-col space-y-6 mt-6">
                {/* Mobile Search */}
                <div className="space-y-4">
                  <Input placeholder="O que você procura?" />
                  <Input placeholder="Localização" />
                  <Input placeholder="Data" />
                  <Input placeholder="Tipo" />
                  <Button className="w-full">Buscar</Button>
                </div>

                {/* Mobile Navigation */}
                <nav className="flex flex-col space-y-4">
                  <a href="#explorar" className="text-gray-700 hover:text-primary transition-colors">Explorar</a>
                  <a href="#mapa" className="text-gray-700 hover:text-primary transition-colors">Mapa</a>
                  <a href="#experiencias" className="text-gray-700 hover:text-primary transition-colors">Experiências</a>
                  <a href="#servicos" className="text-gray-700 hover:text-primary transition-colors">Serviços</a>
                  <a href="#comunidade" className="text-gray-700 hover:text-primary transition-colors">Comunidade</a>
                </nav>

                <Button className="w-full">
                  Entrar/Cadastrar-se
                </Button>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
}