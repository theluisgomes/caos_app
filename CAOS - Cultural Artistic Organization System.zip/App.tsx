import { Header } from './components/Header';
import { HeroSection } from './components/HeroSection';
import { MapSection } from './components/MapSection';
import { ExperiencesSection } from './components/ExperiencesSection';
import { ServicesSection } from './components/ServicesSection';
import { IntersectionTabs } from './components/IntersectionTabs';
import { Footer } from './components/Footer';

export default function App() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main>
        <HeroSection />
        <MapSection />
        <ExperiencesSection />
        <ServicesSection />
        <IntersectionTabs />
      </main>

      <Footer />
    </div>
  );
}